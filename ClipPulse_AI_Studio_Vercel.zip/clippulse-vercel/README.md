# ClipPulse AI Studio — Vercel-ready project

## Run locally
1. Install Node.js (LTS).
2. Open this folder in a terminal.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local URL printed by Vite.

## Deploy to Vercel
1. Upload this folder to a GitHub repository.
2. Sign in to Vercel and choose **Add New → Project**.
3. Import the repository.
4. Framework preset: **Vite** (usually detected automatically).
5. Build command: `npm run build`
6. Output directory: `dist`
7. Click **Deploy**.

## Important limitations
This package wraps the provided React component in a Vite/Tailwind project. The current app's clip generation uses simulated progress and generated placeholder clip metadata; it does not use AI to detect highlights or transcribe real speech. True AI highlight detection, accurate captions, reliable MP4 rendering, and server-side processing require backend services/APIs and additional implementation. Browser recording/export support varies by browser and device. Mirror/zoom/filter effects are not a copyright-protection guarantee; only upload or reuse media you have rights to.
